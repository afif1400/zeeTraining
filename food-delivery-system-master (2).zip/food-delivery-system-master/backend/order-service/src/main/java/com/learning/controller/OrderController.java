package com.learning.controller;

import com.learning.entity.Order;
import com.learning.service.OrderService;
import com.learning.util.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
// @CrossOrigin // handled at gateway (application.yml)
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService service;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping
    public Order saveOrder(@RequestBody Order order, @RequestHeader("Authorization") String token) throws Exception {
        Integer customerId = jwtUtil.getCustomerIdFromToken(token);
        order.setCustomerId(customerId);
        return service.placeOrder(order);
    }

    @GetMapping
    public Iterable<Order> getOrders(@RequestHeader("Authorization") String token) throws Exception {
        Integer customerId = jwtUtil.getCustomerIdFromToken(token);
        return service.getOrdersByCustomer(customerId);
    }
}
