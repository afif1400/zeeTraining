package com.learning.service;

import java.util.Optional;

import com.learning.entity.Cart;
import com.learning.repo.CartRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartService {
    @Autowired
    private CartRepository repo;

    public Cart getCartForUser(Integer userId) {
        Optional<Cart> cart = repo.findById(userId);
        if (cart.isPresent()) {
            return cart.get();
        }

        return null;
    }

    public void saveCart(Cart cart) {
        repo.save(cart);
    }
}
