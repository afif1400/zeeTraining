package com.learning.entity;

import lombok.Data;

@Data
public class LineItem {
    private Food food;
    private Integer quantity;
}
