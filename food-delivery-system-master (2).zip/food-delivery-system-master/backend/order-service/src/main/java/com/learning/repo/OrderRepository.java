package com.learning.repo;

import com.learning.entity.Order;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface OrderRepository extends MongoRepository<Order, String> {
    public Iterable<Order> findAllByCustomerId(Integer customerId);
}