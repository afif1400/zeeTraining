package com.learning.service;

import com.learning.entity.Order;
import com.learning.repo.OrderRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepo;

    public Order placeOrder(Order order) {
        return orderRepo.insert(order);
    }

    public Iterable<Order> getOrdersByCustomer(Integer customerId) {
        return orderRepo.findAllByCustomerId(customerId);
    }
}
