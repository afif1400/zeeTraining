package com.learning.controller;

import java.util.List;

import com.learning.entity.Cart;
import com.learning.entity.LineItem;
import com.learning.service.CartService;
import com.learning.util.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    CartService service;

    @Autowired
    private JwtUtil jwtUtil;

    @GetMapping
    public Cart getCart(@RequestHeader("Authorization") String token) throws Exception {
        Integer userId = jwtUtil.getCustomerIdFromToken(token);
        return service.getCartForUser(userId);
    }

    @PutMapping
    public void saveCart(@RequestBody List<LineItem> items, @RequestHeader("Authorization") String token)
            throws Exception {
        Integer userId = jwtUtil.getCustomerIdFromToken(token);
        Cart cart = new Cart();
        cart.setItems(items);
        cart.setUserId(userId);
        service.saveCart(cart);
    }
}
