package com.learning.entity;

import lombok.Data;

@Data
public class Food {
    private String id;
    private String foodName;
    private Double foodCost;
    private String foodType;
    private String description;
    private String foodPic;
}
