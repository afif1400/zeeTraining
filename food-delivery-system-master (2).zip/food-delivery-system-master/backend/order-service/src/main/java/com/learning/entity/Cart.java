package com.learning.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "user_carts")
public class Cart {
    @Id
    private Integer userId;
    private List<LineItem> items;
}
