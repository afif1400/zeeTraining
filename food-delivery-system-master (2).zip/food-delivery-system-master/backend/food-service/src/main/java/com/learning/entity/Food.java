package com.learning.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "food")
public class Food {
    @Id
    private String id;
    private String foodName;
    private Double foodCost;
    private String foodType;
    private String description;
    private String foodPic;
}
