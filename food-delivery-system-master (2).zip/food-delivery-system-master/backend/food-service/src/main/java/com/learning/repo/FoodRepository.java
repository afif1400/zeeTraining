package com.learning.repo;

import com.learning.entity.Food;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FoodRepository extends MongoRepository<Food, String> {

    public Page<Food> findAllByFoodType(String foodType, PageRequest p);
}
