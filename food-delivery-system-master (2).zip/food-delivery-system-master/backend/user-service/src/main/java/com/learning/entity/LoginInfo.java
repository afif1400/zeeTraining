package com.learning.entity;

import lombok.Data;

@Data
public class LoginInfo {
    private String email;
    private String password;
}
