import { Component, OnInit } from '@angular/core';
import { Food } from 'src/app/model/food';
import { FoodService } from 'src/app/service/food.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  foodList: Array<Food> = [];
  foodType: string = '';
  pageNo: number = 1;

  observer = {
    next: (resp: any) => {
      this.foodList = resp.content;
    }
  }

  constructor(private foodService: FoodService) { }

  ngOnInit(): void {
    this.foodService.getAll(this.pageNo, 8)
      .subscribe(this.observer);
  }

  setPageNo(pageNo: number) {
    this.pageNo = pageNo;
    this.filterByFoodType();
  }

  filterByFoodType() {
    if (this.foodType === '') {
      this.foodService.getAll(this.pageNo, 8)
        .subscribe(this.observer);
    }
    else {
      this.foodService.getByFoodType(this.foodType, this.pageNo, 8)
        .subscribe(this.observer);
    }
  }

}
