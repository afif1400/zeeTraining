import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Order } from 'src/app/model/order';
import { AuthService } from 'src/app/service/auth.service';
import { OrderService } from 'src/app/service/order.service';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {

  orders: Array<Order> | undefined;

  constructor(private orderService: OrderService,
    private authService: AuthService,
    private router: Router) { }

  observer = {
    next: (resp: any) => {
      this.orders = resp;
    },
    error: (err: any) => { }
  }

  ngOnInit(): void {
    if (!this.authService.isAuthenticated()) {
      this.router.navigate(['/']);
    }
    else {
      this.orderService.getOrderHistory().subscribe(this.observer);
    }
  }

  getOrderTotal(order: Order): number {
    let total = 0;
    order.lineItems?.forEach(li => total += li.food.foodCost * li.quantity);
    return total;
  }



}
