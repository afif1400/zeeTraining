import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { Food } from 'src/app/model/food';
import { Order } from 'src/app/model/order';
import { AuthService } from 'src/app/service/auth.service';
import { CartService } from 'src/app/service/cart.service';
import { OrderService } from 'src/app/service/order.service';

@Component({
  selector: 'app-view-cart',
  templateUrl: './view-cart.component.html',
  styleUrls: ['./view-cart.component.css']
})
export class ViewCartComponent implements OnInit {

  constructor(private cartService: CartService,
    private authService: AuthService,
    private router: Router,
    private orderService: OrderService) { }

  ngOnInit(): void {
    if (this.cartItems.length === 0) {
      this.router.navigate(['/']);
    }
  }

  observer: any = {
    next: (resp: any) => {
      // show an alert 
      // redirect to home page
      this.cartService.emptyCart();
      this.orderService.currentOrder = { ...resp };
      this.router.navigate(['/order-success']);
    },
    error: (err: any) => { }
  }

  get cartItems() {
    return this.cartService.getCartItems();
  }

  get cartTotal() {
    return this.cartService.getCartTotal();
  }

  deleteFromCart(food: Food) {
    this.cartService.deleteFromCart(food);
    if (this.cartItems.length === 0) {
      this.router.navigate(['/']);
    }
  }

  checkout() {
    if (this.authService.isAuthenticated()) {
      // place the order
      let order = new Order();
      order.lineItems = [...this.cartService.getCartItems()];
      this.orderService.placeOrder(order)
        .subscribe(this.observer);
    }
    else {
      // redirect to login page
      // and on successful login, redirect back to /view-cart page
      this.router.navigate(['/login'], { queryParams: { redirectTo: '/view-cart' } })
    }
  }
}
