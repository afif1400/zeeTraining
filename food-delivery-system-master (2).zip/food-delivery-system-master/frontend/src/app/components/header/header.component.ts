import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/service/auth.service';
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private authService: AuthService, private cartService: CartService) { }

  ngOnInit(): void {
  }

  logout(): void {
    this.authService.logout();
  }

  get isAuthenticated(): boolean {
    return this.authService.isAuthenticated();
  }

  get isAdmin(): boolean {
    return this.authService.isAdmin();
  }

  get loggedInName(): string | undefined {
    return this.authService.loggedInName();
  }

  get isCartEmpty() {
    return this.cartService.isEmpty();
  }

  get getCartSize() {
    return this.cartService.getCartSize();
  }

  get cartTotal() {
    return this.cartService.getCartTotal();
  }
}
