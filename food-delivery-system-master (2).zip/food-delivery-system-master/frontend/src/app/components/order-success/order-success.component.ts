import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Order } from 'src/app/model/order';
import { User } from 'src/app/model/user';
import { AuthService } from 'src/app/service/auth.service';
import { OrderService } from 'src/app/service/order.service';
import { textChangeRangeIsUnchanged } from 'typescript';

@Component({
  selector: 'app-order-success',
  templateUrl: './order-success.component.html',
  styleUrls: ['./order-success.component.css']
})
export class OrderSuccessComponent implements OnInit {

  order: Order | undefined;
  user: User | undefined;

  constructor(private orderService: OrderService,
    private router: Router,
    private authService: AuthService) { }

  ngOnInit(): void {
    if (!this.orderService.currentOrder) {
      this.router.navigate(['/']);
    }
    else {
      this.user = this.authService.loggedInUser() as User;
      console.log('user is', this.user);
      this.order = this.orderService.currentOrder;
    }
  }

  get orderTotal(): any {
    if (this.order) {
      let total = 0;
      this.order.lineItems?.forEach(li => total += li.food.foodCost * li.quantity);
      return total;
    }
    return null;
  }

}
