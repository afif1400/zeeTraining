import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginInfo: { email: string, password: string } = { email: '', password: '' };
  err: { error: any } = {
    error: undefined
  };

  constructor(private authService: AuthService, private router: Router,
    private activatedRoute: ActivatedRoute) { }


  ngOnInit(): void {
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/']);
    }
  }

  observer = {
    next: (resp: any) => {
      console.log('next() handler called')
      this.activatedRoute.queryParams.subscribe(qp => {
        if ('redirectTo' in qp) {
          console.log('redirecting to', qp['redirectTo']);
          this.router.navigate([qp['redirectTo']]);
        }
        else if ('token' in resp) {
          console.log('redirecting to /');
          this.router.navigate(['/']);
        }
      });

    },
    error: (err: any) => { this.err = err; console.log('error() handler called', err) }
  }



  login() {
    this.authService.login(this.loginInfo.email, this.loginInfo.password)
      .subscribe(this.observer);
  }


}
