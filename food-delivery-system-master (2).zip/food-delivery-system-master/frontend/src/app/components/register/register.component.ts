import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user: User = new User();
  cpassword: string = 'topsecret';

  registerHandler = {
    next: (resp: any) => {
      if ('id' in resp) {
        alert('Registration succeeded');
        this.router.navigate(['/login']);
      }
    },
    error: (err: any) => { }
  }

  constructor(private authService: AuthService, private router: Router) { }


  ngOnInit(): void {
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/']);
    }
  }

  register(): void {
    this.authService.register(this.user)
      .subscribe(this.registerHandler);
  }

  get passwordMatch() {
    return this.cpassword === this.user.password;
  }

}
