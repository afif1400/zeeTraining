import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { foodUrl } from 'src/constants';
import { Food } from '../model/food';

@Injectable({
  providedIn: 'root'
})
export class FoodService {

  constructor(private httpClient: HttpClient) { }

  getAll(page: number = 1, size: number = 10): Observable<any> {
    return this.httpClient.get(foodUrl, { params: { page, size } });
  }

  getByFoodType(foodType: string, page: number = 1, size: number = 10): Observable<any> {
    return this.httpClient.get(foodUrl + '/filter', { params: { foodType, page, size } });
  }

  getFood(id: string) {
    return this.httpClient.get(foodUrl + '/' + id);
  }

  deleteFood(id: string) {
    return this.httpClient.delete(foodUrl + '/' + id);
  }

  addNewFood(food: Food) {
    return this.httpClient.post(foodUrl, food);
  }

  updateFood(food: Food) {
    return this.httpClient.put(foodUrl + '/' + food.id, food);
  }
}
