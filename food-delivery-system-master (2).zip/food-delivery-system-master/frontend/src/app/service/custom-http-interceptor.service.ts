import { HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomHttpInterceptorService implements HttpInterceptor {

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let { token } = sessionStorage;
    if (!token) {
      return next.handle(req);
    }

    let headers = new HttpHeaders({ Authorization: `Jwt ${token}` });
    let newReq = req.clone({ headers });
    return next.handle(newReq);
  }
}
