import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { loginUrl, registerUrl } from 'src/constants';

import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private token: any;
  private user: any;
  private name: any;

  constructor(private httpClient: HttpClient) {

    if ('token' in sessionStorage) {
      this.token = sessionStorage.getItem('token');
    }
    if ('user' in sessionStorage) {
      this.user = sessionStorage.getItem('user');
      this.user = JSON.parse(this.user);
    }
    if ('name' in sessionStorage) {
      this.name = sessionStorage.getItem('name');
    }
  }

  isAdmin(): boolean {
    return this.user && this.user.id === 0;
  }

  isAuthenticated(): boolean {
    return this.token ? true : false;
  }

  loggedInName(): any {
    return this.name;
  }

  loggedInUser(): any {
    return { ...this.user };
  }

  logout(): void {
    this.token = undefined;
    this.user = undefined;
    this.name = undefined;
    //sessionStorage.clear();
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('user');
    sessionStorage.removeItem('name');
  }

  login(email: string, password: string): Observable<any> {
    return this.httpClient
      .post<string>(loginUrl, { email, password })
      .pipe(tap((resp: any) => {
        if ('token' in resp) {
          this.token = resp.token;
          this.user = resp.user;
          this.name = resp.user.name;
          sessionStorage.setItem('user', JSON.stringify(this.user));
          sessionStorage.setItem('name', this.user.name);
          sessionStorage.setItem('token', this.token);

          if (this.syncCart) {
            this.syncCart();
          }
        }
      }));
  }

  syncCart: any = undefined;
  setSyncCart(syncCart: any) {
    this.syncCart = syncCart;
  }

  register(user: User): Observable<any> {
    return this.httpClient.post(registerUrl, user);
  }


}
