import { LineItem } from "./line-item";

export class Order {
    orderId?: string;
    customerId?: number;
    orderDate?: string;
    lineItems?: Array<LineItem>;
}
