export class Address {
    houseno?: number;
    street?: string;
    city?: string;
    state?: string;
    zipcode?: number;
}
