export class Food {
    id?: string = '';
    foodName: String = '';
    foodCost: number = 0;
    foodType: string = 'Indian';
    description: string = '';
    foodPic: string = '';
}
