import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditFoodComponent } from './components/edit-food/edit-food.component';
import { FoodDetailsComponent } from './components/food-details/food-details.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { NewFoodComponent } from './components/new-food/new-food.component';
import { OrderHistoryComponent } from './components/order-history/order-history.component';
import { OrderSuccessComponent } from './components/order-success/order-success.component';
import { RegisterComponent } from './components/register/register.component';
import { ViewCartComponent } from './components/view-cart/view-cart.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: HomeComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'food-details/:id',
    component: FoodDetailsComponent
  },
  {
    path: 'view-cart',
    component: ViewCartComponent
  },
  {
    path: 'order-success',
    component: OrderSuccessComponent
  },
  {
    path: 'order-history',
    component: OrderHistoryComponent
  },
  {
    path: 'add-food-item',
    component: NewFoodComponent
  },
  {
    path: 'edit-food-item/:id',
    component: EditFoodComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
