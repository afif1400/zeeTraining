import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { HomeComponent } from './components/home/home.component';
import { FormsModule } from '@angular/forms';
import { FoodCardComponent } from './components/food-card/food-card.component';
import { FoodDetailsComponent } from './components/food-details/food-details.component';
import { AddToCartButtonComponent } from './components/add-to-cart-button/add-to-cart-button.component';
import { ViewCartComponent } from './components/view-cart/view-cart.component';
import { CustomHttpInterceptorService } from './service/custom-http-interceptor.service';
import { OrderSuccessComponent } from './components/order-success/order-success.component';
import { OrderHistoryComponent } from './components/order-history/order-history.component';
import { NewFoodComponent } from './components/new-food/new-food.component';
import { EditFoodComponent } from './components/edit-food/edit-food.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    FoodCardComponent,
    FoodDetailsComponent,
    AddToCartButtonComponent,
    ViewCartComponent,
    OrderSuccessComponent,
    OrderHistoryComponent,
    NewFoodComponent,
    EditFoodComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [
    {
      useClass: CustomHttpInterceptorService,
      provide: HTTP_INTERCEPTORS,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
