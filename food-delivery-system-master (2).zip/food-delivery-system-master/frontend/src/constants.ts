const baseUrl = 'http://localhost:8080/api'

export const loginUrl = `${baseUrl}/authenticate`;
export const registerUrl = `${baseUrl}/register`;
export const foodUrl = `${baseUrl}/food`;
export const ordersUrl = `${baseUrl}/orders`;
export const cartUrl = `${baseUrl}/cart`;